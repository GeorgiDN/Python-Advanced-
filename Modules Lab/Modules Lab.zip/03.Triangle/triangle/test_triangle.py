from triangle import triangle_main

size = int(input())
triangle_main.print_triangle(size)
